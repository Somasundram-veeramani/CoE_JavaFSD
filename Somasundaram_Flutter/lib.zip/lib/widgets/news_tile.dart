import 'package:flutter/material.dart';
import '../models/news_model.dart';
import '../services/bookmark_service.dart';

class NewsTile extends StatefulWidget {
  final NewsArticle article;
  const NewsTile({Key? key, required this.article}) : super(key: key);

  @override
  _NewsTileState createState() => _NewsTileState();
}

class _NewsTileState extends State<NewsTile> {
  final BookmarkService _bookmarkService = BookmarkService();

  bool isBookmarked = false;

  @override
  void initState() {
    super.initState();
    isBookmarked = widget.article.isBookmarked;
  }

  void toggleBookmark() {
    setState(() {
      isBookmarked = !isBookmarked;
    });

    if (isBookmarked) {
      _bookmarkService.addBookmark(widget.article);
    } else {
      _bookmarkService.removeBookmark(widget.article.title);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 3,
      margin: EdgeInsets.symmetric(vertical: 8, horizontal: 16),
      child: ListTile(
        leading: widget.article.imageUrl.isNotEmpty
            ? Image.network(widget.article.imageUrl, width: 80, fit: BoxFit.cover)
            : Icon(Icons.image, size: 80),
        title: Text(widget.article.title, maxLines: 2, overflow: TextOverflow.ellipsis),
        subtitle: Text(widget.article.description, maxLines: 2, overflow: TextOverflow.ellipsis),
        trailing: IconButton(
          icon: Icon(isBookmarked ? Icons.bookmark : Icons.bookmark_border, color: Colors.blue),
          onPressed: toggleBookmark,
        ),
      ),
    );
  }
}
