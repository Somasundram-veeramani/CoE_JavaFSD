import 'dart:convert';
import 'package:http/http.dart' as http;

class NewsService {
  static const String apiKey = "f81ee99498484a71bf353e51e8301f71"; // Replace with your API key
  static const String baseUrl = "https://newsapi.org/v2/top-headlines?country=us";

  Future<List<dynamic>> fetchNews() async {
    final response = await http.get(Uri.parse("$baseUrl&apiKey=$apiKey"));

    if (response.statusCode == 200) {
      final data = jsonDecode(response.body);
      return data['articles'];
    } else {
      throw Exception("Failed to load news");
    }
  }
}
