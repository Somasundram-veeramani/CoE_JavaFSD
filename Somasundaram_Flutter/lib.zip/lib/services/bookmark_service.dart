import 'package:flutter/material.dart';

class BookmarkService with ChangeNotifier {
  final List<dynamic> _bookmarks = [];

  List<dynamic> get bookmarks => List.unmodifiable(_bookmarks);

  void addBookmark(dynamic article) {
    if (!_bookmarks.any((a) => a['title'] == article['title'])) {
      _bookmarks.add(article);
      notifyListeners();
    }
  }

  void removeBookmark(dynamic article) {
    _bookmarks.removeWhere((a) => a['title'] == article['title']);
    notifyListeners();
  }

  bool isBookmarked(dynamic article) {
    return _bookmarks.any((a) => a['title'] == article['title']);
  }

  List<dynamic> getBookmarks() {
    return _bookmarks;
  }
}
