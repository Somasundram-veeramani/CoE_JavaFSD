class NewsArticle {
  final String title;
  final String description;
  final String url;
  final String imageUrl;
  final bool isBookmarked;

  NewsArticle({
    required this.title,
    required this.description,
    required this.url,
    required this.imageUrl,
    this.isBookmarked = false,
  });

  Map<String, dynamic> toMap() {
    return {
      'title': title,
      'description': description,
      'url': url,
      'imageUrl': imageUrl,
      'isBookmarked': isBookmarked,
    };
  }

  factory NewsArticle.fromMap(Map<String, dynamic> map) {
    return NewsArticle(
      title: map['title'],
      description: map['description'],
      url: map['url'],
      imageUrl: map['imageUrl'],
      isBookmarked: map['isBookmarked'] ?? false,
    );
  }
}
