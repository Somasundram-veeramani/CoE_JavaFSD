import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/bookmark_service.dart';

class BookmarksPage extends StatelessWidget {
  const BookmarksPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("Bookmarked News")),
      body: Consumer<BookmarkService>(
        builder: (context, bookmarkService, child) {
          final bookmarks = bookmarkService.bookmarks;

          if (bookmarks.isEmpty) {
            return const Center(child: Text("No bookmarks yet."));
          }

          return ListView.builder(
            itemCount: bookmarks.length,
            itemBuilder: (context, index) {
              final article = bookmarks[index];

              return ListTile(
                title: Text(article['title'] ?? "No Title"),
                subtitle: Text(article['description'] ?? "No Description"),
                leading: article['urlToImage'] != null
                    ? Image.network(article['urlToImage'], width: 80, fit: BoxFit.cover)
                    : const Icon(Icons.image, size: 80),
                trailing: IconButton(
                  icon: const Icon(Icons.delete, color: Colors.red),
                  onPressed: () {
                    bookmarkService.removeBookmark(article);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text("Removed from bookmarks")),
                    );
                  },
                ),
              );
            },
          );
        },
      ),
    );
  }
}
