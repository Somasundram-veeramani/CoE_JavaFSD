import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class ThemeProvider with ChangeNotifier {
  bool _isDarkMode = false;

  bool get isDarkMode => _isDarkMode;

  ThemeProvider() {
    _loadTheme(); // Load saved theme on startup
  }

  void toggleTheme() async {
    final newMode = !_isDarkMode;
    if (newMode != _isDarkMode) {
      _isDarkMode = newMode;
      notifyListeners();
      await _saveTheme(); // Save the new theme
    }
  }

  Future<void> _saveTheme() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool("isDarkMode", _isDarkMode);
  }

  Future<void> _loadTheme() async {
    final prefs = await SharedPreferences.getInstance();
    bool savedTheme = prefs.getBool("isDarkMode") ?? false;
    if (savedTheme != _isDarkMode) {
      _isDarkMode = savedTheme;
      notifyListeners();
    }
  }
}
