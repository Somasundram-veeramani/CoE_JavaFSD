import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class LocaleProvider with ChangeNotifier {
  Locale _locale = const Locale('en'); // Default language is English

  Locale get locale => _locale;

  LocaleProvider() {
    _loadLocale(); // Load saved locale when app starts
  }

  void setLocale(Locale newLocale) {
    if (_locale == newLocale) return;
    _locale = newLocale;
    _saveLocale(newLocale.languageCode);
    notifyListeners();
  }

  Future<void> toggleLocale() async {
    if (_locale.languageCode == 'en') {
      setLocale(const Locale('ta')); // Switch to Tamil
    } else {
      setLocale(const Locale('en')); // Switch to English
    }
  }

  Future<void> _saveLocale(String languageCode) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString('language_code', languageCode);
  }

  Future<void> _loadLocale() async {
    final prefs = await SharedPreferences.getInstance();
    String? languageCode = prefs.getString('language_code');
    if (languageCode != null) {
      _locale = Locale(languageCode);
      notifyListeners();
    }
  }
}
