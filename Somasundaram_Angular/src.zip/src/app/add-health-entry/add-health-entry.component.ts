import { Component } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { HealthService } from '../services/health.service';

@Component({
  selector: 'app-add-health-entry',
  templateUrl: './add-health-entry.component.html',
  styleUrls: ['./add-health-entry.component.css']
})
export class AddHealthEntryComponent {
  healthForm: FormGroup;

  constructor(private fb: FormBuilder, private healthService: HealthService) {
    this.healthForm = this.fb.group({
      date: [''],
      weight: [''],
      steps: [''],
      sleep: [''],
      water: [''],
      heartRate: ['']
    });
  }

  submitForm() {
    this.healthService.addHealthLog(this.healthForm.value);
    this.healthForm.reset();
  }
}
