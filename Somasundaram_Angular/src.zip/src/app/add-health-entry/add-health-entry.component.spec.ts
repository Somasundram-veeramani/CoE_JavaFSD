import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddHealthEntryComponent } from './add-health-entry.component';

describe('AddHealthEntryComponent', () => {
  let component: AddHealthEntryComponent;
  let fixture: ComponentFixture<AddHealthEntryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [AddHealthEntryComponent]
    })
    .compileComponents();
    
    fixture = TestBed.createComponent(AddHealthEntryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
