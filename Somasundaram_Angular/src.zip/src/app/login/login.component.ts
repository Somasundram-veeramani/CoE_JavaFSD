import { Component } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  username: string = '';
  password: string = '';

  constructor(private router: Router) {}

  login() {
    if (this.password === '123') { // Fixed password
      localStorage.setItem('username', this.username);
      localStorage.setItem('isLoggedIn', 'true'); // Store login status
      this.router.navigate(['/dashboard']); // Redirect to dashboard
    } else {
      alert('Invalid credentials');
    }
  }
}
