export interface HealthLog {
    date: string;
    weight: number;  
    steps: number;
    sleep: number;
    water: number;
    heartRate: number;
  }
  