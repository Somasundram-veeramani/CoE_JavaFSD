import { Component, OnInit, OnDestroy } from '@angular/core';
import { HealthService } from '../services/health.service';
import { Subscription } from 'rxjs';
import { HealthLog } from '../models/health.model';

@Component({
  selector: 'app-health-log',
  templateUrl: './health-log.component.html',
  styleUrls: ['./health-log.component.css']
})
export class HealthLogComponent implements OnInit, OnDestroy {
  healthLogs: HealthLog[] = [];
  private subscription!: Subscription;

  constructor(private healthService: HealthService) {}

  ngOnInit() {
    this.subscription = this.healthService.healthLogs$.subscribe(logs => {
      this.healthLogs = logs || [];
    });
  }

  deleteLog(date: string) {
    this.healthService.deleteLog(date);
  }

  ngOnDestroy() {
    this.subscription.unsubscribe(); // ✅ Prevents memory leaks
  }
}
