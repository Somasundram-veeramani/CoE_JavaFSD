import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HealthService } from '../services/health.service';
import { HealthLog } from '../models/health.model';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.css']
})
export class DashboardComponent implements OnInit {
  latestLog: HealthLog | null = null;
  username: string = 'User';

  constructor(private healthService: HealthService, private router: Router) {}

  ngOnInit() {
    const storedUsername = localStorage.getItem('username') || 'User';
    this.username = storedUsername.toUpperCase(); // Ensuring uppercase

    this.healthService.healthLogs$.subscribe(logs => {
      if (logs.length > 0) {
        this.latestLog = logs[logs.length - 1];
      }
    });
  }

  logout() {
    localStorage.removeItem('username');
    localStorage.removeItem('isLoggedIn'); // Clear login status
    this.router.navigate(['/login']); // Redirect to login
  }
}
