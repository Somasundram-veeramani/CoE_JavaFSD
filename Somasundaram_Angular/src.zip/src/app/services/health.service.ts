import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { HealthLog } from '../models/health.model';

@Injectable({
  providedIn: 'root'
})
export class HealthService {
  private healthLogs: HealthLog[] = JSON.parse(localStorage.getItem('healthLogs') || '[]');
  private healthSubject = new BehaviorSubject<HealthLog[]>(this.healthLogs);

  healthLogs$ = this.healthSubject.asObservable();

  addHealthLog(log: HealthLog) {
    this.healthLogs.push(log);
    this.updateStorage();
  }

  deleteLog(date: string) {
    this.healthLogs = this.healthLogs.filter(log => log.date !== date);
    this.updateStorage();
  }

  private updateStorage() {
    localStorage.setItem('healthLogs', JSON.stringify(this.healthLogs));
    this.healthSubject.next(this.healthLogs);
  }
}
